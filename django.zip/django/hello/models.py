from django.db import models

# Create your models here.
class userDistance(models.Model):
    distance = models.IntegerField()