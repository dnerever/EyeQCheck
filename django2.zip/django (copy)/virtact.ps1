Set-Location -Path C:\Users\jdgeo\HackCU9\EyeQCheck\django
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
.venv\scripts\activate
py manage.py runserver